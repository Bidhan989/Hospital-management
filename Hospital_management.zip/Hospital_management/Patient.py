class Patient:
    """Patient class"""
    
    def __init__(self, first_name, surname, age, mobile, postcode, Address, symptoms=''):
        """
        Args:
            first_name (string): First name
            surname (string): Surname
            age (int): Age
            mobile (string): Mobile number
            postcode (string): Postcode
        """
        self.__first_name = first_name
        self.__surname = surname
        self.__age = age
        self.__mobile = mobile
        self.__postcode = postcode
        self.__symptoms = symptoms  
        self.__Address = Address
        self.__doctor = None

    def get_first_name(self):
        return self.__first_name

    def get_surname(self):
        return self.__surname

    def get_age(self):
        return self.__age

    def get_mobile(self):
        return self.__mobile

    def get_postcode(self):
        return self.__postcode
    
    def get_Address(self):
        return self.__Address

    def get_symptoms(self):
        return self.__symptoms

    def set_first_name(self, first_name):
        self.__first_name = first_name

    def set_surname(self, surname):
        self.__surname = surname

    def set_age(self, age):
        self.__age = age

    def set_mobile(self, mobile):
        self.__mobile = mobile

    def set_postcode(self, postcode):
        self.__postcode = postcode

    def set_Address(self, Address):
        self.__Address = Address

    def set_symptoms(self, symptoms):
        self.__symptoms = symptoms

    def link(self, doctor):
        self.__doctor = doctor

    def get_doctor(self):
        return self.__doctor

    def full_name(self):
        return f"{self.__first_name} {self.__surname}"

    def __str__(self):
        doctor_name = self.__doctor.full_name() if self.__doctor else "Not Assigned"
        return f'{self.full_name():^24}|{doctor_name:^25}|{self.__age:^5}|{self.__mobile:^15}|{self.__postcode:^10}|{self.__Address:^15}|{self.__symptoms:^20}'
