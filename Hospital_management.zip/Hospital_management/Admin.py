from Doctor import Doctor
from Patient import Patient
class Admin:
    """A class that deals with Admin operations"""
    
    def __init__(self, username='', password='', address=''):
        """
        Args:
            username (string): Username
            password (string): Password
            address (string, optional): Address Defaults to ''
        """
        self.__address = address
        self.credentials_file = "admin_credentials.txt"
        self.__username = username
        self.__password = password
        self.load_credentials()
        self.patients_file = "patients.txt"

    def view(self, a_list):
        """
        print a list
        Args:
            a_list (list): a list of printables
        """
        for index, item in enumerate(a_list):
            print(f'{index+1:3}|{item}')

    def load_credentials(self):
        """Loads admin credentials from a file or creates default ones if the file is empty."""
        try:
            with open(self.credentials_file, "r") as file:
                credentials = file.readline().strip().split(",")
                if len(credentials) == 2:
                    self.__username, self.__password = credentials
        except FileNotFoundError:
            self.save_credentials()  # Creates the file with default credentials

    def save_credentials(self):
        """Saves the updated admin credentials to the file."""
        with open(self.credentials_file, "w") as file:
            file.write(f"{self.__username},{self.__password}")

    def login(self):
        """
        A method that deals with the login
        Raises:
            Exception: returned when the username and the password ...
                    ... don`t match the data registered
        Returns:
            string: the username
        """
        
        print("-----Login-----")
        while True:
            username = input("Enter the username: ")
            password = input("Enter the password: ")

            if username == self.__username and password == self.__password:
                print("Login successful!")
                return username
            else:
                print("Invalid username or password. Try again.")
                continue

    def find_index(self, index, doctors):
            
        if index in range(0,len(doctors)):
            return True
        else:
            return False

    def get_doctor_details(self):
        """
        Get the details needed to add a doctor
        Returns:
            first name, surname and ...
                            ... the speciality of the doctor in that order.
        """
        first_name = input("Enter doctor's first name: ")
        surname = input("Enter doctor's surname: ")
        speciality = input("Enter doctor's speciality: ")
        return first_name, surname, speciality

    def doctor_management(self, doctors):
        """
        A method that deals with registering, viewing, updating, deleting doctors
        Args:
            doctors (list<Doctor>): the list of all the doctors names
        """
        print("-----Doctor Management-----")
        print('Choose the operation:')
        print(' 1 - Register ')
        print(' 2 - View ')
        print(' 3 - Update ')
        print(' 4 - Delete ')

        op = input('Input: ')

        if op == '1':
            print("-----Register-----")

            print('Enter the doctor\'s details:')
            first_name, surname, speciality = self.get_doctor_details()

            for doctor in doctors:
                if first_name == doctor.get_first_name() and surname == doctor.get_surname():
                    print('Name already exists.')
                    return
                
            new_doctor = Doctor(first_name, surname, speciality)
            doctors.append(new_doctor)
            print("Doctor registered successfully.")

        # for View
        elif op == '2':
            print("-----List of Doctors-----")
            self.view(doctors)

        # for Update   
        elif op == '3':
            while True:
                print("-----Update Doctor`s Details-----")
                print('ID |          Full name           |  Speciality')
                self.view(doctors)
                try:
                    index = int(input('Enter the ID of the doctor: ')) - 1
                    doctor_index=self.find_index(index,doctors)
                    if doctor_index:
                
                        break
                    
                    else:
                        print("Doctor not found")

                except ValueError: # the entered id could not be changed into an int
                    print('The ID entered is incorrect')

            # menu
            print('Choose the field to be updated:')
            print(' 1 First name')
            print(' 2 Surname')
            print(' 3 Speciality')
            op = input('Input: ') 

            #ToDo8
            
            if op == '1':
                    new_name = input("Enter new first name: ")
                    doctors[index].set_first_name(new_name)
                    print("Updated successfully")
            elif op == '2':
                    new_surname = input("Enter new surname: ")
                    doctors[index].set_surname(new_surname)
                    print("Updated successfully")
            elif op == '3':
                    new_speciality = input("Enter new speciality: ")
                    doctors[index].set_speciality(new_speciality)
                    print("Updated successfully")
            else:
                print("Invalid choice.")

        # Delete
        elif op == '4':
            print("-----Delete Doctor-----")
            print('ID |          Full Name           |  Speciality')
            self.view(doctors)

            try:
                index = int(input('Enter the doctor ID to delete: ')) - 1
                if 0 <= index < len(doctors):
                    del doctors[index]
                    print("Doctor deleted successfully.")
                else:
                    print("The ID entered was not found.")
            except ValueError:
                print("Invalid input.")

        else:
            print('Invalid operation choosen. Check your spelling!')

    def view_patient(self, patients):
        """
            print a list of patients
            Args:
            patients (list<Patients>): list of all the active patients
        """
        print("-----View Patients-----")
        print('ID |       Full Name        |      Doctor`s Full Name      | Age |    Mobile     | Postcode | Address | Symptom ')
        self.view(patients)

    def add_patient(self, patients):
        """
        Allows the admin to add a new patient to the system
        Args:
            patients (list<Patient>): the list of all the patients
        """
        print("-----Add New Patient-----")
        first_name = input("Enter patient's first name: ")
        surname = input("Enter patient's surname: ")
        age = int(input("Enter patient's age: "))
        mobile = input("Enter patient's mobile number: ")
        postcode = input("Enter patient's postcode: ")
        Address = input("Enter patient's address: ")
        symptoms = input("Enter patient's symptoms: ")

        for patient in patients:
            if patient.get_first_name() == first_name and patient.get_surname() == surname:
                print(f"Patient {first_name} {surname} already exists.")
                return
        
        new_patient = Patient(first_name,surname,age,mobile,postcode,Address,symptoms)
        patients.append(new_patient)
        print(f"Patient {first_name} {surname} added successfully.")

    def assign_doctor_to_patient(self, patients, doctors):
        """
        Allow the admin to assign a doctor to a patient
        Args:
        patients (list<Patients>): the list of all the active patients
        doctors (list<Doctor>): the list of all the doctors
        """
        print("-----Assign-----")
        print("-----Patients-----")
        print('ID |       Full Name        |      Doctor`s Full Name      | Age |    Mobile     | Postcode | Address | Symptom ')
        self.view(patients)

        try:
            patient_index = int(input('Enter patient ID: ')) - 1
            if not self.find_index(patient_index, patients):
                print('Invalid patient ID.')
                return
        except ValueError:
            print('Invalid input.')
            return

        print("-----Doctors-----")
        self.view(doctors)

        try:
            doctor_index = int(input('Enter doctor ID: ')) - 1
            if doctor_index not in range(len(doctors)):
                print('Invalid doctor ID.')
                return
        except ValueError:
            print('Invalid input.')
            return

        if patients[patient_index].get_doctor():
            print(f"{patients[patient_index].full_name()} already has a doctor assigned.")
            return

        patients[patient_index].link(doctors[doctor_index])
        doctors[doctor_index].add_patient(patients[patient_index])
        print(f"{patients[patient_index].full_name()} is now assigned to Dr. {doctors[doctor_index].full_name()}.")

    def relocate_patient(self, patients, doctors):
        """Reassigns a patient to another doctor"""
        print("-----Relocate Patient-----")
        self.view(patients)

        try:
            patient_index = int(input('Enter patient ID: ')) - 1
            if 0 <= patient_index < len(patients):
                self.view(doctors)
                doctor_index = int(input('Enter new doctor ID: ')) - 1
                if 0 <= doctor_index < len(doctors):
                    patients[patient_index].link(doctors[doctor_index])
                    print(f"Patient relocated to Dr. {doctors[doctor_index].full_name()}.")
                else:
                    print("Invalid doctor ID.")
            else:
                print("Invalid patient ID.")
        except ValueError:
            print("Invalid input.")

    def discharge(self, patients, discharged_patients):
        """
        Allow the admin to discharge a patient when treatment is done
        Args:
            patients (list<Patients>): the list of all the active patients
            discharge_patients (list<Patients>): the list of all the non-active patients
        """
        print("-----Discharge Patient-----")
        print('ID |       Full Name        |    Doctor`s Full Name   | Age |    Mobile     | Postcode |    Address    |     Symptom ')
        self.view(patients)

        try:
            patient_index = int(input('Enter patient ID: ')) - 1
            if not self.find_index(patient_index, patients):
                print('Invalid patient ID.')
                return
            discharged_patients.append(patients.pop(patient_index))
            print("Patient discharged successfully.")
        except ValueError:
            print('Invalid input.')

    def view_discharge(self, discharged_patients):
        """
        Prints the list of all discharged patients
        Args:
            discharge_patients (list<Patients>): the list of all the non-active patients
        """

        print("-----Discharged Patients-----")
        print('ID |       Full Name        |    Doctor`s Full Name   | Age |    Mobile     | Postcode |    Address    |     Symptom ')
        self.view(discharged_patients)

    def group_family_members(self, patients):
        """Groups family members based on surname"""
        print("-----Grouping Family Members-----")
        family_groups = {}
        
        for patient in patients:
            surname = patient.get_surname()
            if surname in family_groups:
                family_groups[surname].append(patient.full_name())
            else:
                family_groups[surname] = [patient.full_name()]
        
        for surname, members in family_groups.items():
            print(f"Family {surname}: {', '.join(members)}")

    def save_patient_data(self, patients):
        """Saves patient data to a file"""
        with open(self.patients_file, "w") as file:
            for patient in patients:
                file.write(f"{patient.get_first_name()},{patient.get_surname()},{patient.get_age()},{patient.get_mobile()},{patient.get_postcode()},{patient.get_Address()},{patient.get_symptoms()}\n")
        print("Patient data saved successfully.")

    def load_patient_data(self):
        """Loads patient data from a file"""
        patients = []
        try:
            with open(self.patients_file, "r") as file:
                for line in file:
                    data = line.strip().split(",")
                    if len(data) == 7:
                        first_name, surname, age, mobile, postcode, address ,symptom = data
                        patients.append(Patient(first_name, surname, int(age), mobile, postcode, address, symptom))
            print("Patient data loaded successfully.")
        except FileNotFoundError:
            print("No saved patient data found.")
        return patients

    def generate_report(self, doctors, patients):
        """
        Generate a management report with the following details:
        - Total number of doctors
        - Total number of patients per doctor
        - Total number of appointments per month per doctor
        """
        # 1. Total number of doctors and patient in the system
        total_doctors = len(doctors)
        print(f"Total number of doctors: {total_doctors}")

        total_patients = len(patients)
        print(f"Total number of patients: {total_patients}")

        # 2. Total number of patients per doctor
        for doctor in doctors:
            total_patients = len(doctor.get_patients())
            print(f"Dr. {doctor.full_name()} has {total_patients} patients.")

        # 3. Total number of appointments per month per doctor
        doctor_appointments = {}  # Dictionary to count appointments per month for each doctor
        for doctor in doctors:
            for appointment in doctor.get_appointments():
                month = appointment.split('-')[1]  # Extract month from date (assuming date format is 'YYYY-MM-DD')
                if doctor.full_name() not in doctor_appointments:
                    doctor_appointments[doctor.full_name()] = {}
                if month not in doctor_appointments[doctor.full_name()]:
                    doctor_appointments[doctor.full_name()][month] = 0
                doctor_appointments[doctor.full_name()][month] += 1
        
        for doctor in doctor_appointments:
            for month, count in doctor_appointments[doctor].items():
                print(f"Dr. {doctor} has {count} appointments in month {month}.")

    def update_details(self):
        """
        Allows the user to update and change username, password and address
        """

        print('Choose the field to update:')
        print(' 1 - Username')
        print(' 2 - Password')
        print(' 3 - Address')
        op = input('Input: ')

        if op == '1':
            self.__username = input("Enter new username: ")
            print("Username updated successfully.")

        elif op == '2':
            while True:
                new_password = input("Enter new password: ")
                confirm_password = input("Confirm new password: ")

                if new_password == confirm_password:
                    self.__password = new_password
                    print("Password updated successfully.")
                    break
                else:
                    print("Passwords do not match. Try again.")
        elif op == '3':

            self.__address = input("Enter new address: ")
            print("Address updated successfully.")
        else:
            print("Invalid choice.")
        
        self.save_credentials()  
