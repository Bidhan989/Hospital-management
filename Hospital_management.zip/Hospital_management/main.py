from Admin import Admin
from Doctor import Doctor
from Patient import Patient
def main():
    """
    the main function to be ran when the program runs
    """

    # Initialising the actors
    admin = Admin('admin','123','B1 1AB')
    doctors = [Doctor('John','Smith','Internal Med.'), Doctor('Jone','Smith','Pediatrics'), Doctor('Jone','Carlos','Cardiology')]
    patients = admin.load_patient_data()
    if not patients:
        patients = [Patient('Sara','Smith', 20, '07012345678','B1 234','New street','fever'), Patient('Mike','Jones', 37,'07555551234','L2 2AB','Bullring','Cough'), Patient('Daivd','Smith', 15, '07123456789','C1 ABC','Moor Street','headache')]
    discharged_patients = []

    # keep trying to login tell the login details are correct
    while True:
        if admin.login():
            running = True # allow the program to run
            break
        else:
            while not admin.login():
                print("Try again.")

    while running:
        # Print the menu
        print('\nChoose an operation:')
        print(' 1- Register/view/update/delete doctor')
        print(' 2 - View patients')
        print(' 3 - Add new patient')
        print(' 4 - Assign a doctor to a patient')
        print(' 5 - Relocate a patient to another doctor')
        print(' 6 - Discharge a patient')
        print(' 7 - View discharged patients')
        print(' 8 - Group family members')
        print(' 9 - Save patient data to file')
        print(' 10 - Load patient data from file')
        print(' 11 - Update admin details')
        print(' 12 - Generate management report')
        print(' 13 - Quit')

        # Get the option
        op = input('Option: ')

        if op == '1':
            admin.doctor_management(doctors)

        elif op == '2':
            admin.view(patients)

        elif op == '3':
            admin.add_patient(patients)
            
        elif op == '4':
            admin.assign_doctor_to_patient(patients, doctors)

        elif op == '5':
            admin.relocate_patient(patients, doctors)

        elif op == '6':
            if patients:  
                admin.discharge(patients, discharged_patients)

                while True:
                    op = input('Do you want to discharge a patient(Y/N):').lower()

                    if op == 'yes' or op == 'y':
                        admin.view_discharge(discharged_patients)
                        break

                    elif op == 'no' or op == 'n':
                        break

                    else:
                        print('Please answer by yes or no.')
                        return #break
            else:
                print("No patients to discharge")
        
        elif op == '7':
            admin.view_discharge(discharged_patients)
        
        elif op == '8':
            admin.group_family_members(patients)
        
        elif op == '9':
            admin.save_patient_data(patients)
        
        elif op == '10':
            patients = admin.load_patient_data()
        
        elif op == '11':
            admin.update_details()
        
        elif op == '12':
            admin.generate_report(doctors, patients)
        
        elif op == '13':
            print("Exiting the program...")
            running = False
        else:
            print('Invalid option. Try again.')

if __name__ == '__main__':
    main()